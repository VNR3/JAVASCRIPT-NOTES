/* example on creating external script */
function fun1()
{
	document.write("hi, im fun1");
}

function fun2()
{
  document.write("hi, im fun2");
}

//Note: svae this file with a name "test .js" in current folder
